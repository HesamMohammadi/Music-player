import { seekAudiotoTime, isAudioPlaying, playAudio, pauseAudio } from "./audio";
import {rotateEqualizerImage, stopEqualizerimagerotation } from "./Equlaizer/equalizerImage";

const seekbar = document.querySelector('#seekbar');
const playpauseBtn = document.querySelector('#play-pause-btn');

function listenToaudioTimeupdate () {
    document.addEventListener( 'audioTimeUpdate' , e => {
        let currentTime = e.detail.currentTime;
        let duration = e.detail.duration;
        updateSeekbar(currentTime, duration);
        updateAudiocurrentTimeAndduration(currentTime, duration);
    });
}

function updateSeekbar (currentTime, duration) {
    seekbar.max = duration;
    seekbar.value = currentTime;
}

function updateAudiocurrentTimeAndduration(currentTime, duration) {
    document.querySelector('#current-time').innerHTML = convertsecondtominute(currentTime);
    document.querySelector('#music-duration').innerHTML = convertsecondtominute(duration);
}

function listentoseekbarChange () {
    seekbar.addEventListener('input', () => {
        seekAudiotoTime(seekbar.value);
    });
}
    

function convertsecondtominute(seconds) {
    seconds = Math.floor(seconds);
    let minutes = Math.floor(seconds / 60);
    let remainingsecond = seconds % 60;
    return minutes + ':' + (remainingsecond < 10 ? '0' : '') + remainingsecond;
}

function setClickEventonPlayPauseBtn () {
    playpauseBtn.addEventListener('click', () => {
        if (isAudioPlaying()) {
            pauseAudio();
            stopEqualizerimagerotation();
            setplaypauseBtnASplay();
        } else {
            playAudio();
            rotateEqualizerImage();
            setplaypauseBtnASpause();
        }

    });
}

function setplaypauseBtnASplay () {
    playpauseBtn.style.backgroundImage = "url('/img/play.png')";
}
function setplaypauseBtnASpause () {
    playpauseBtn.style.backgroundImage = "url('/img/pause.png')";
}

listentoseekbarChange();
listenToaudioTimeupdate();
setClickEventonPlayPauseBtn();

export {setplaypauseBtnASplay, setplaypauseBtnASpause}