import { playAudio, pauseAudio, isAudioPlaying } from './audio';
import { setplaypauseBtnASplay, setplaypauseBtnASpause } from './seekbar';
import { setEqualizerimg, rotateEqualizerImage, stopEqualizerimagerotation } from "./Equlaizer/equalizerImage";

function handlemusicclick(music) {
    if (isAudioPlaying()) {
        pauseAudio();
        stopEqualizerimagerotation(); // این خط اضافه شد
        setplaypauseBtnASplay();
    } else {
        playAudio(); // این خط اضافه شد
        setEqualizerimg(music.cover_image);
        rotateEqualizerImage(); // این خط اضافه شد
        setplaypauseBtnASpause();
    }
    setEqualizerimg(music.cover_image);
}

export default handlemusicclick;