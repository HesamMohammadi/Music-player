import Swiper from 'swiper';
import 'swiper/css';
import { setupAudio, playAudio } from './audio';
import handlemusicclick from './handlemusicclicke';
import { setplaypauseBtnASplay, setplaypauseBtnASpause } from './seekbar';
import { setEqualizerimg, rotateEqualizerImage, stopEqualizerimagerotation } from "./Equlaizer/equalizerImage";

let musicsData;
let currentMusicUuid = null;

function createslider(musics) {
    const swiperWrapper = document.querySelector('.swiper-wrapper');
    swiperWrapper.innerHTML = '';

    musics.forEach(music => {
        let slideHtml = `
            <div class="swiper-slide" data-uuid="${music.uuid || ''}">
                <img class="music-image" src="/${music.cover_image || ''}" alt="">
                <div class="music-title">${music.title || ''}</div>
                <div class="music-artist">${music.artist || ''}</div>
            </div>
        `;
        swiperWrapper.insertAdjacentHTML('beforeend', slideHtml);
    });

    new Swiper('.swiper', {
        slidesPerView: 10,
        spaceBetween: 10,
        loop: true,
        freeMode: true,
    });
}

function setClickListenerOnslideritems() {
    document.querySelectorAll('.swiper-slide').forEach(slide => {
        slide.addEventListener('click', () => {
            let uuid = slide.getAttribute('data-uuid');
            let foundMusic = findMusic(uuid);
            setMusicinfoInDom(foundMusic);

            setEqualizerimg(foundMusic.cover_image); // این خط را اضافه کن

            if (currentMusicUuid === uuid) {
                handlemusicclick(foundMusic);
            } else {
                setupAudio(foundMusic.url, foundMusic.uuid);
                playAudio();
                rotateEqualizerImage(); // این خط را اضافه کن
                setplaypauseBtnASpause();
                currentMusicUuid = uuid;
            }
        });
    });
}


function findMusic(uuid) {
    return musicsData.find(music => music.uuid === uuid) || null;
}

function setMusicinfoInDom(music) {
    document.querySelector('#title').innerHTML = music.title || '';
    document.querySelector('#artist').innerHTML = music.artist || '';
    document.querySelector('#genre').innerHTML = music.genre || '';
    document.querySelector('#lyric').innerHTML = music.lyric.split('\n').join('<br>') || '';
}

function passDataToSliderMoudule(musics) {
    musicsData = musics;
    createslider(musics);
    setClickListenerOnslideritems();
}

export { passDataToSliderMoudule, setMusicinfoInDom };