import handlemusicclick from './handlemusicclicke';
import { setMusicinfoInDom } from './slider';
import {audio, setupAudio, playAudio } from './audio';


const searchinput = document.querySelector('#search-input');
const searchedMusicsDiv = document.querySelector('#searched-musics');
let musics = [];

function listenToKeyupEvent(){
    searchinput.addEventListener('keyup' , e => {
        let keyword = e.target.value?.toLowerCase();
        let searchedmusics = searchmusic(keyword);
        clearSerachedMusics();
        showSearchedMusics(searchedmusics).then(() => setClickListernerToSearchedMusics());
    });
}

function clearSerachedMusics(){
    searchedMusicsDiv.innerHTML = '';    
}

function searchmusic(keyword){
    if (!keyword) return [];

    let filteredmusics = musics.filter(music => {
        let title = music.title?.toLowerCase();
        let artist = music.artist?.toLowerCase();
        let jenre = music.genre?.toLowerCase();
        if (title.indexOf(keyword) !== -1 || artist.indexOf(keyword)!== -1 || jenre.indexOf(keyword)!== -1){
            return true;
        }else{
            return false;
        }
    });
    return filteredmusics;
}

function showSearchedMusics (musics) {
    return new Promise(resolve => {
        musics.forEach(music => {
        let musicHTML = `<div class="searched-music" data-uuid="${music.uuid}">
                           <div>
                                <div>${music.title}</div>
                                <div>${music.artist}</div>
                            </div>
                            <img src="${music.cover_image}" alt="">
                        </div>`
        searchedMusicsDiv.innerHTML += musicHTML
     });
    resolve()
    });
}

function passDatatoSearchMoudule(musicsData){
    musics = musicsData;
}

function setClickListernerToSearchedMusics(){
    document.querySelectorAll('.searched-music').forEach(musicDiv => {
        musicDiv.addEventListener('click', () => {
            let uuid = musicDiv.getAttribute('data-uuid');
            let foundMusic = musics.find(music => music.uuid === uuid);
            setMusicinfoInDom(foundMusic);
            setupAudio(foundMusic.url, foundMusic.uuid);
            // پخش فقط بعد از آماده شدن audio
            audio.addEventListener('canplay', () => {
                playAudio();
            }, { once: true });
            handlemusicclick(foundMusic);
        });
    });
}
document.addEventListener('click', function(e) {
    const searchInput = document.getElementById('search-input');
    const searchedMusicsDiv = document.getElementById('searched-musics');
    // اگر کلیک روی خود سرچ یا لیست بود، کاری نکن
    if (
        searchInput.contains(e.target) ||
        searchedMusicsDiv.contains(e.target)
    ) return;
    // در غیر این صورت لیست جستجو را پاک کن
    searchedMusicsDiv.innerHTML = '';
});
searchinput.addEventListener('click', () => {
    let keyword = searchinput.value?.toLowerCase();
    let searchedmusics = searchmusic(keyword);
    clearSerachedMusics();
    showSearchedMusics(searchedmusics).then(() => setClickListernerToSearchedMusics());
});

listenToKeyupEvent();
export {passDatatoSearchMoudule};