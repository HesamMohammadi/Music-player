import './equalizerImage';
import './progressbar'
import './equalizerCanvas'
import equalizerWidth from './equalizerWidth';

function setEqualizerdimintion () {
    const equalizersection = document.querySelector('#equalizer-section')
    equalizersection.style.width = equalizerWidth + 'px'
    equalizersection.style.height = equalizerWidth + 'px'
}

setEqualizerdimintion()