import equalizerWidth from "./equalizerWidth";
const equalizerImage = document.querySelector('#equalizer-img');

function setEqualizerimg(imageUrl) {
    if (!imageUrl) return;
    if (!imageUrl.startsWith('/')) {
        imageUrl = '/' + imageUrl;
    }
    equalizerImage.src = imageUrl;
}

function setEqualizerimgdimention () {
    equalizerImage.style.width = equalizerWidth + 'px';
    equalizerImage.style.height = equalizerWidth + 'px';
}

function rotateEqualizerImage() {
    equalizerImage.classList.add('rotate');
}

function stopEqualizerimagerotation() {
    equalizerImage.classList.remove('rotate');
}

setEqualizerimgdimention ();

export { setEqualizerimg, rotateEqualizerImage, stopEqualizerimagerotation };