const equalizerWidth = 250 
export default equalizerWidth;