import { getfrequencyData } from "../audio";
import equalizerWidth from "./equalizerWidth";
import { progressbarthickness } from "./progressbar";

const Canvas = document.querySelector('#equalizer-canvas');
const context = Canvas.getContext('2d');
function listenToaudioTimeupdate () {
    document.addEventListener( 'audioTimeUpdate' , e => {
        clearCanvsas();
        DrawEqualizer(getfrequencyData())
    });
}

function DrawEqualizer(frequencyData) {
    let slicecount = 100;
    let radius = equalizerWidth / 2 + progressbarthickness + 8;
    let maxHight = 60
    let maxFrequency = 255

    frequencyData.slice(0, slicecount).map(freqency => Math.pow(freqency/maxFrequency, 4)*maxFrequency).forEach((frequency, index) => {
        let angle = 2 * Math.PI / slicecount * index;
        let x1 = Canvas.width/ 2 + radius * Math.cos(angle);
        let y1 = Canvas.height/ 2 - radius * Math.sin(angle);

        let lineHeight = frequency / maxFrequency * maxHight;
        let percent = angle / (2 * Math.PI)
        let x2 = Canvas.width/ 2 + (radius + lineHeight) * Math.cos(angle);
        let y2 = Canvas.height/ 2 - (radius + lineHeight) * Math.sin(angle);
        drawLine({x1, y1, x2, y2, percent});
    });
}

function setCanvasDimintion() {
    Canvas.width = equalizerWidth * 2;
    Canvas.height = equalizerWidth * 2;
}

function clearCanvsas() {
    context.clearRect(0, 0, Canvas.width, Canvas.height);
}

function drawLine({x1, y1, x2, y2, percent}) {
    context.beginPath();
    context.moveTo(x1, y1);
    context.lineTo(x2, y2);
    context.strokeStyle = interpolateColor(percent);
    context.lineWidth = 8;
    context.lineCap = 'round';
    context.stroke();
}

function interpolateColor (percent) {
    const colors = [
        [0, 255, 204],

        [255, 102, 102],
        [255, 204, 0],
        [102, 255, 102],
        [102, 178, 255],
        [0, 255, 204]
    ];
    percent = Math.max(0, Math.min(1, percent));

    let index = Math.floor(percent * (colors.length - 1));
    let factor = (percent * (colors.length - 1)) - index;

    let color1 = colors[index];
    let color2 = colors[index + 1] || colors[index];

    const result = color1.map((c, i) => Math.round(c + factor * (color2[i] - c)));
    return `rgb(${result.join(",")})`;
}


listenToaudioTimeupdate();
setCanvasDimintion();