import equalizerWidth from './equalizerWidth';

const progressbar = document.querySelector('#circular-progressbar');
const progressbarColor = 'white'
const progressbarthickness = 5;

function listenToaudioTimeupdate () {
    document.addEventListener( 'audioTimeUpdate' , e => {
        let currentTime = e.detail.currentTime;
        let duration = e.detail.duration;
        let angle = (currentTime / duration) * 360;
        updateprogressbar(angle);
    });
}

function setProgressbardimintion (){
    progressbar.style.width = (equalizerWidth + 2 * progressbarthickness) + 'px';
    progressbar.style.height = (equalizerWidth + 2 * progressbarthickness) + 'px';
}

function updateprogressbar (angle) {
    progressbar.style.background = `conic-gradient(${progressbarColor} 0 ${angle}deg , transparent ${angle}deg 360deg)`;
}

listenToaudioTimeupdate();
setProgressbardimintion();

export {progressbarthickness};