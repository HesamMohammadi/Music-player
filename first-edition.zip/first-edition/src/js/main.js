import fetchData from './fetchdata.js';
import { passDataToSliderMoudule } from './slider.js';
import { passDatatoSearchMoudule } from './searchmusics.js';
import './seekbar.js';
import './Equlaizer/equalizer.js';
import './searchmusics.js';

async function getData() {
    let musics = await fetchData();
    passDataToSliderMoudule(musics);
    passDatatoSearchMoudule(musics);
}

getData();