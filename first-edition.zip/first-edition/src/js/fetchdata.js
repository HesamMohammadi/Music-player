function fetchData () {
    return fetch('https://cdn.jsdelivr.net/gh/HesamMohammadi/Music-player/music.json')
        .then(response => response.json())
        .catch(error => {
            console.error('Fetch error:', error);
            return [];
        });
}

export default fetchData;