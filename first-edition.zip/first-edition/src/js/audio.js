let audio = null;
let musicTimes = {};
let lastMusicKey = null;
let audioContext
let source
let analyser
let frequencyData

// ...existing code...
function listenTotimeUpdate() {
    audio.addEventListener('timeupdate', () => {
        let currentTime = audio.currentTime;
        let duration = audio.duration || 0;
        let event = new CustomEvent('audioTimeUpdate', {
            detail: {
                currentTime,
                duration
            }
        });
        document.dispatchEvent(event);
    });

    audio.addEventListener('pause', () => {
        const event = new CustomEvent('audioPaused');
        document.dispatchEvent(event);
    });
    audio.addEventListener('ended', () => {
        const event = new CustomEvent('audioPaused');
        document.dispatchEvent(event);
    });
}

function setupAudio(url, key) {
    // تبدیل mp3 به mp4 اگر فایل mp3 وجود ندارد
    if (url && url.endsWith('.mp3')) {
        url = url.replace('.mp3', '.mp4');
    }
    if (url && !url.startsWith('/')) {
        url = '/' + url;
    }

    if (audio && lastMusicKey) {
        musicTimes[lastMusicKey] = audio.currentTime;
        audio.pause();
        audio.currentTime = 0;
    }

    audio = new Audio(url);
    if (musicTimes[key]) {
        audio.currentTime = musicTimes[key];
    }
    lastMusicKey = key;

    // AudioContext و Analyser را اینجا مقداردهی کن
    audioContext = new AudioContext();
    source = audioContext.createMediaElementSource(audio);
    analyser = audioContext.createAnalyser();
    frequencyData = new Uint8Array(analyser.frequencyBinCount);

    source.connect(analyser);
    analyser.connect(audioContext.destination);

    listenTotimeUpdate();
}

function getfrequencyData() {
    if (!analyser) {
        console.error('Analyser is not initialized.');
        return [];
    }
    analyser.getByteFrequencyData(frequencyData);
    return frequencyData;
}

function playAudio() {
    if (audio) {
        audio.play();
    }
}

function pauseAudio() {
    if (audio) {
        audio.pause();
    }
}

function isAudioPlaying() {
    return audio && !audio.paused;
}



function seekAudiotoTime (time) {
    audio.currentTime = time;
}

export {audio, setupAudio, playAudio, pauseAudio, isAudioPlaying, seekAudiotoTime, getfrequencyData};